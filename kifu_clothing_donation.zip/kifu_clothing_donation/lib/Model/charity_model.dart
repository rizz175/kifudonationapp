class charity_model
{



  String email;
  String name;

  charity_model(this.email, this.name);

}