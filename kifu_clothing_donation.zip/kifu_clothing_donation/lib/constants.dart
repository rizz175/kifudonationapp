import 'dart:ui';

import 'package:flutter/material.dart';

var primaryColor=Color(0xff427BD2);
var headingstyle=TextStyle(fontWeight:FontWeight.bold,color:Colors.white,fontSize:25);
var headingstyle2=TextStyle(fontWeight:FontWeight.bold,color:Colors.black,fontSize:25);
